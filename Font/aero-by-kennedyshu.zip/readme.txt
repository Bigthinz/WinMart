﻿=== Aero Cursor Set ===

By: Sho Kennedy Shu (http://www.rw-designer.com/user/23847) kennedyshu@hotmail.com

Download: http://www.rw-designer.com/cursor-set/aero-by-kennedyshu

Author's decription:

simple and professional cursors resembling to the windows Vista or 7 default cursor

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.